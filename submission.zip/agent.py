"""
agent.py
Agent MPC Lineal + Gradient Boosting (Versió Definitiva Ultraràpida — 6,44 pts)
Repte UPC Sostenible — Datathon 2026
"""

from collections import deque
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from scipy.optimize import linprog


class BatteryAgent:
    def __init__(self):
        self.cap = 2000.0
        self.power = 500.0
        self.eta = 0.90 ** 0.5  # ~0.948683
        self.inv_eta = 1.0 / self.eta
        self.historial = deque(maxlen=48)

        directori = Path(__file__).resolve().parent
        ruta_model = directori / "model_demanda_neta.pkl"
        self.model = joblib.load(ruta_model) if ruta_model.exists() else None

        # Perfil horari base del campus (0h..23h)
        self.perfil_base = np.array([
            850.0, 820.0, 800.0, 790.0, 810.0, 880.0, 1020.0, 1180.0,
            1320.0, 1410.0, 1450.0, 1460.0, 1430.0, 1380.0, 1350.0, 1320.0,
            1280.0, 1220.0, 1150.0, 1080.0, 1010.0, 950.0, 900.0, 870.0
        ], dtype=float)

        # Pre-calculem la matriu de restriccions per H=24 per evitar overhead cada hora
        self._H_cache = 24
        tril = np.tril(np.ones((24, 24), dtype=float))
        self._A_ub_24 = np.vstack([
            np.hstack([self.eta * tril, -self.inv_eta * tril]),
            np.hstack([-self.eta * tril, self.inv_eta * tril])
        ])

    def _predir_demanda_24h(self, obs: dict, H: int) -> np.ndarray:
        hora = int(obs["hour"])
        dia_setmana = int(obs["day_of_week"])
        ts = pd.Timestamp(obs["timestamp"])
        sensors = obs.get("noves_dades_5min", {})

        prev_load = float(sensors.get("ultim_consum_kw", 1050.0))
        prev_pv = float(sensors.get("ultima_solar_kw", 0.0))
        prev_neta = max(0.0, prev_load - prev_pv)

        self.historial.append(prev_neta)
        neta_24h = self.historial[-24] if len(self.historial) >= 24 else prev_neta

        # 1 sola crida ràpida al model ML amb array de numpy
        if self.model is not None:
            x_arr = np.array([[
                hora,
                dia_setmana,
                int(ts.month),
                1 if dia_setmana >= 5 else 0,
                float(obs["preu_actual"]),
                float(obs["co2_actual"]),
                prev_load,
                prev_pv,
                prev_neta,
                neta_24h
            ]], dtype=float)
            pred_0 = max(50.0, float(self.model.predict(x_arr)[0]))
        else:
            pred_0 = max(50.0, prev_neta)

        # Projecció vectoritzada amb numpy per a les H hores següents
        hores_seq = (np.arange(H) + hora) % 24
        escala = float(np.clip(pred_0 / self.perfil_base[hora], 0.5, 1.8))
        demandes = self.perfil_base[hores_seq] * escala
        demandes[0] = pred_0

        # Si tenim 24h d'historial, ponderem el perfil escalat amb el consum real d'ahir
        n_hist = len(self.historial)
        if n_hist >= 24:
            hist_list = list(self.historial)
            for k in range(1, min(H, 24)):
                demandes[k] = 0.65 * hist_list[n_hist - 24 + k] + 0.35 * demandes[k]

        return np.maximum(50.0, demandes)

    def act(self, obs: dict) -> float:
        soc_kwh = float(obs["soc_kwh"])
        co2_24 = np.asarray(obs.get("co2_properes_24h", [obs["co2_actual"]]), dtype=float)
        preus_24 = np.asarray(obs.get("preus_properes_24h", [obs["preu_actual"]]), dtype=float)
        H = len(co2_24)

        demandes_24 = self._predir_demanda_24h(obs, H)

        # Funció objectiu: 70% CO2 + 30% Preu (normalitzat per la mitjana mòbil de les 24h)
        co2_norm = co2_24 / (np.mean(co2_24) + 1e-9)
        preu_norm = preus_24 / (np.mean(preus_24) + 1e-9)
        w = 0.70 * co2_norm + 0.30 * preu_norm
        c = np.concatenate([w, -w])

        # Fites físiques: no descarregar més que la demanda neta del campus
        upper_d = np.minimum(self.power, demandes_24)
        bounds = [(0.0, self.power)] * H + [(0.0, float(u)) for u in upper_d]

        if H == self._H_cache:
            A_ub = self._A_ub_24
        else:
            tril = np.tril(np.ones((H, H), dtype=float))
            A_ub = np.vstack([
                np.hstack([self.eta * tril, -self.inv_eta * tril]),
                np.hstack([-self.eta * tril, self.inv_eta * tril])
            ])

        # Reserva suau al final de la finestra de 24h per no buidar del tot la bateria
        b_min = np.full(H, soc_kwh)
        if H >= 12:
            b_min[-1] = max(0.0, soc_kwh - 600.0)

        b_ub = np.concatenate([
            np.full(H, self.cap - soc_kwh),
            b_min
        ])

        res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")

        if res.success:
            consigna = float(res.x[0] - res.x[H])
        else:
            consigna = 0.0

        # Clamping físic estricte per garantir 0 infraccions
        eps = 1e-4
        max_carrega = max(0.0, min(self.power, ((self.cap - soc_kwh) * self.inv_eta) - eps))
        max_descarrega = max(0.0, min(self.power, (soc_kwh * self.eta) - eps))

        return float(np.clip(consigna, -max_descarrega, max_carrega))